from django.test import TestCase

class CoreModelTests(TestCase):
    def test_example(self):
        # Example test case
        self.assertEqual(1 + 1, 2)